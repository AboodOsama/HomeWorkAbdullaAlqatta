package Lab8Queue2;

public interface interface2 {

}
